/* Mero Bazar ext.js — ADD-ON ONLY. Does not edit app.js or any other file's logic.
   Pattern is the same as home.js / orders.js: wrap global functions (R, pc, feed, act, add, setO, oCard, checkout),
   and register extra screens in the existing SV map. Per-user extras live in S.u.x (small object).
   Cloud data: only `reviews` (needs the 6 new lines in firestore.rules). */
(function(){
'use strict';
const ne=()=>typeof DB!=='undefined'&&!!DB&&DB.lang==='ne',L=(a,b)=>ne()?a:b;
const fsx=()=>{try{return firebase.firestore()}catch(_){return null}},au=()=>{try{return firebase.auth().currentUser}catch(_){return null}};
const X=()=>{const u=S.u;if(!u)return {sv:{s:[],p:[]},ad:[],bk:[],fl:[],qr:[]};const x=u.x=u.x||{};x.sv=x.sv||{s:[],p:[]};x.ad=x.ad||[];x.bk=x.bk||[];x.fl=x.fl||[];x.qr=x.qr||[];return x};
const has=(a,i)=>a.includes(i),tog=(a,i)=>{const k=a.indexOf(i);k<0?a.push(i):a.splice(k,1);return k<0};
const role=()=>S.u&&S.u.role;
const css=document.createElement('style');css.textContent=`
.xs{display:flex;gap:8px;overflow-x:auto;padding:2px 0 10px;scrollbar-width:none}
.xc{flex:0 0 150px;background:var(--card);border:1px solid var(--ln);border-radius:12px;padding:9px;cursor:pointer;font-size:13px}
.xc b{display:block;font-size:13.5px;margin-bottom:2px}
.xh{margin:10px 2px 4px;font-size:16px;font-weight:800}
.xp{background:var(--card);border:1px solid var(--ln);border-radius:12px;padding:10px;margin-bottom:10px}
.xp .row2{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
.xin{width:100%;padding:10px;border:1px solid var(--ln);border-radius:10px;font-size:15px;margin:4px 0;background:var(--card);color:inherit}
.xbar{display:flex;align-items:flex-end;gap:6px;height:90px;margin:8px 0}.xbar i{flex:1;background:var(--saf,#E8820C);border-radius:4px 4px 0 0;min-height:2px;position:relative}
.xbar i span{position:absolute;bottom:-16px;left:0;right:0;text-align:center;font-size:10px;font-style:normal;color:var(--mu)}
.xtl{border-left:3px solid var(--ln);margin:6px 0 6px 8px;padding-left:12px}.xtl div{margin:8px 0;position:relative}.xtl div:before{content:"";position:absolute;left:-19px;top:3px;width:11px;height:11px;border-radius:50%;background:var(--ln)}.xtl .d:before{background:#2e7d32}
.xm{position:fixed;inset:0;z-index:100001;background:var(--bg,#fff);color:var(--tx,#111);overflow:auto;padding:14px;font-family:inherit}
`;document.head.appendChild(css);
const BTN='padding:10px 14px;border:0;border-radius:10px;font-size:14px;font-weight:700;background:var(--ind,#1E2B6E);color:#fff;cursor:pointer';
function modal(html){const w=document.createElement('div');w.className='xm';w.innerHTML='<div style="max-width:720px;margin:0 auto"><button id="xclose" style="float:right;'+BTN+'">'+L('बन्द','Close')+'</button>'+html+'</div>';document.body.appendChild(w);w.querySelector('#xclose').onclick=()=>w.remove();return w}
const go=s=>{S.sub=s;R()};
const lkx=(s,i,t)=>`<div class="c row" style="cursor:pointer" onclick="S.sub='${s}';R()"><span>${i} <b>${t}</b></span><b>›</b></div>`;

/* ================= Reviews & ratings (cloud: reviews/{cuid_suid}) ================= */
let RV={};
async function loadRV(){const f=fsx();if(!f||!au())return;try{const s=await f.collection('reviews').get(),m={};
  s.forEach(d=>{const x=d.data();if(!x.suid||!(x.r>=1))return;const o=m[x.suid]=m[x.suid]||{n:0,sum:0,list:[]};o.n++;o.sum+=x.r;o.list.push(x)});
  Object.values(m).forEach(o=>o.list.sort((a,b)=>b.ts-a.ts));const ch=JSON.stringify(Object.keys(m).map(k=>[k,m[k].n,m[k].sum]))!==JSON.stringify(Object.keys(RV).map(k=>[k,RV[k].n,RV[k].sum]));RV=m;
  if(ch&&S.u){const a=document.activeElement;if(!(a&&/INPUT|TEXTAREA|SELECT/.test(a.tagName)))R()}}catch(e){console.warn('rv',e.code||e)}}
const shopUid=s=>s&&(s._uid||(S.u&&s.id===S.u.id&&au()?au().uid:''));
const rating=s=>{const o=RV[shopUid(s)];return o&&o.n?{a:o.sum/o.n,n:o.n}:null};
const stars=a=>'⭐ '+a.a.toFixed(1)+' ('+a.n+')';
window.xRate=function(mid){const s=U(mid),su=shopUid(s),me=au();if(!s||!s.shop)return;if(!su||!me)return toast(L('क्लाउड जोडिएको छैन — लगआउट गरी फेरि लगइन गर्नुहोस्','Cloud not connected — log out and in again'));
  const old=(RV[su]&&RV[su].list.find(x=>x.cuid===me.uid))||{r:5,t:''};let r=old.r;
  const w=modal('<h2>⭐ '+L('रेटिङ दिनुहोस्','Rate')+' — '+E(s.shop.name)+'</h2><div id="xst" style="font-size:34px;letter-spacing:6px;cursor:pointer"></div><textarea id="xt" class="xin" rows="3" maxlength="300" placeholder="'+L('प्रतिक्रिया (ऐच्छिक)','Comment (optional)')+'">'+E(old.t)+'</textarea><button id="xs" style="'+BTN+';width:100%">'+L('पठाउनुहोस्','Submit')+'</button>');
  const dr=()=>{w.querySelector('#xst').innerHTML=[1,2,3,4,5].map(i=>'<span data-i="'+i+'" style="opacity:'+(i<=r?1:.25)+'">★</span>').join('');w.querySelectorAll('[data-i]').forEach(e=>e.onclick=()=>{r=+e.dataset.i;dr()})};dr();
  w.querySelector('#xs').onclick=async()=>{try{await fsx().collection('reviews').doc(me.uid+'_'+su).set({suid:su,cuid:me.uid,r,t:w.querySelector('#xt').value.trim().slice(0,300),n:S.u.name||'',ts:Date.now()});toast('✅');w.remove();loadRV()}catch(e){toast('Review: '+(e.code||e))}}};
const canRate=s=>role()=='c'&&DB.orders.some(o=>o.cid==S.u.id&&o.mid==s.id&&o.st=='Delivered');

/* ================= Holiday / shop closed ================= */
const hol=s=>{const h=s&&s.shop&&s.shop.hol;return !!(h&&h.on&&(!h.to||today()<=h.to)&&(!h.from||today()>=h.from))};
const _add=window.add;if(typeof _add=='function')window.add=function(id){const p=DB.products.find(x=>x.id==id),s=p&&U(p.mid);if(s&&hol(s))return toast('🏖️ '+L('पसल बिदामा छ','Shop is on holiday')+(s.shop.hol.msg?': '+s.shop.hol.msg:''));return _add.apply(this,arguments)};

/* ================= Blocked shops (customer) — hides a shop everywhere via act() ================= */
const _act=window.act;if(typeof _act=='function')window.act=function(s){try{if(S.u&&S.u.role=='c'&&s&&has(X().bk,s.id))return false}catch(_){}return _act.apply(this,arguments)};

/* ================= Product card: ♡ save + ⭐ featured ================= */
const _pc=window.pc;if(typeof _pc=='function')window.pc=function(p){let h=_pc.apply(this,arguments);try{
  if(p.ft)h=h.replace('<div class="nm">','<div class="nm">⭐ ');
  if(role()=='c'&&h.indexOf('<div class="ft">')>-1)h=h.replace('<div class="ft">','<div class="ft"><button class="btn sm g" onclick="xSaveP('+p.id+')">'+(has(X().sv.p,p.id)?'❤️':'🤍')+'</button>');}catch(_){}return h};
window.xSaveP=id=>{const on=tog(X().sv.p,id);save();toast(on?'❤️ '+L('सुरक्षित भयो','Saved'):L('हटाइयो','Removed'));R()};
window.xSaveS=id=>{const on=tog(X().sv.s,id);save();toast(on?'❤️ '+L('सुरक्षित भयो','Saved'):L('हटाइयो','Removed'));R()};
window.xFollow=id=>{const on=tog(X().fl,id);save();toast(on?'✅ '+L('फलो गरियो','Following'):L('फलो हटाइयो','Unfollowed'));R()};
window.xBlock=id=>{const on=tog(X().bk,id);save();toast(on?'🚫 '+L('पसल ब्लक भयो','Shop blocked'):L('ब्लक हटाइयो','Unblocked'));if(on){S.sub=null;S.tab='home'}R()};
window.xShare=id=>{const s=U(id);if(!s||!s.shop)return;const t='🛍️ '+s.shop.name+' — Mero Bazar';if(navigator.share)navigator.share({title:s.shop.name,text:t}).catch(()=>{});else if(navigator.clipboard)navigator.clipboard.writeText(t).then(()=>toast(L('कपी भयो','Copied')))};

/* ================= Search filters (price / distance / ward / rating / availability) ================= */
const F={pmin:'',pmax:'',km:'',ward:'',rt:'',stock:0},fon=()=>F.pmin!==''||F.pmax!==''||F.km!==''||F.ward!==''||F.rt!==''||F.stock;
const _feed=window.feed;if(typeof _feed=='function')window.feed=function(){const a=_feed.apply(this,arguments);if(!fon()||role()!='c')return a;
  return a.filter(x=>{if(x.title)return false;const s=U(x.mid);if(!s)return false;const e=eff(x);
    if(F.pmin!==''&&e<+F.pmin)return false;if(F.pmax!==''&&e>+F.pmax)return false;
    if(F.km!==''){const d=km(s);if(d<9999&&d>+F.km)return false}
    if(F.ward!==''&&String(s.ward)!==String(F.ward))return false;
    if(F.rt!==''){const r=rating(s);if(!r||r.a<+F.rt)return false}
    if(F.stock&&x.stock<=0)return false;return true})};
window.xFApply=()=>{const g=i=>document.getElementById(i);F.pmin=g('xf_pmin').value.trim();F.pmax=g('xf_pmax').value.trim();F.km=g('xf_km').value.trim();F.ward=g('xf_w').value.trim();F.rt=g('xf_rt').value;F.stock=g('xf_st').checked?1:0;S.fc=8;R()};
window.xFReset=()=>{F.pmin=F.pmax=F.km=F.ward=F.rt='';F.stock=0;S.fc=8;R()};
const filterBox=()=>{const d=document.createElement('details');d.id='xfilter';d.className='xp';d.open=!!fon();
  d.innerHTML='<summary style="font-weight:700;cursor:pointer">🎛️ '+L('फिल्टर','Filters')+(fon()?' ●':'')+'</summary><div class="g2" style="margin-top:6px"><input class="xin" id="xf_pmin" type="number" placeholder="'+L('न्यूनतम मूल्य','Min price')+'" value="'+E(F.pmin)+'"><input class="xin" id="xf_pmax" type="number" placeholder="'+L('अधिकतम मूल्य','Max price')+'" value="'+E(F.pmax)+'"><input class="xin" id="xf_km" type="number" placeholder="'+L('दूरी (कि.मी.)','Distance (km)')+'" value="'+E(F.km)+'"><input class="xin" id="xf_w" type="number" placeholder="'+L('वडा नं.','Ward no.')+'" value="'+E(F.ward)+'"></div><select class="xin" id="xf_rt"><option value="">'+L('रेटिङ: सबै','Rating: any')+'</option>'+[3,4,4.5].map(v=>'<option value="'+v+'"'+(String(F.rt)==String(v)?' selected':'')+'>⭐ '+v+'+</option>').join('')+'</select><label style="display:block;margin:6px 0"><input type="checkbox" id="xf_st"'+(F.stock?' checked':'')+'> '+L('स्टकमा भएका मात्र','In stock only')+'</label><div class="row2"><button style="'+BTN+'" onclick="xFApply()">'+L('लागू गर्नुहोस्','Apply')+'</button><button style="'+BTN+';background:#777" onclick="xFReset()">'+L('रिसेट','Reset')+'</button></div>';return d};

/* ================= Home: Trending / Discounts / Popular shops / Recommended / Following ================= */
function sold(){const m={};DB.orders.forEach(o=>{if(o.st=='Cancelled')return;o.items.forEach(i=>m[i.pid]=(m[i.pid]||0)+i.q)});return m}
function strip(title,items){if(!items.length)return null;const w=document.createElement('div');w.innerHTML='<div class="xh">'+title+'</div><div class="xs">'+items.join('')+'</div>';return w}
const pcard=p=>{const s=U(p.mid);return '<div class="xc" onclick="S.sid='+s.id+';S.sub=\'shop\';R()"><b>'+(p.ft?'⭐ ':'')+E(p.name)+'</b><span style="color:var(--saf);font-weight:800">'+rs(eff(p))+'</span>'+(p.dis?' <span class="bd R">-'+Math.round(p.dis/p.price*100)+'%</span>':'')+'<div class="st" style="text-transform:none">'+E(s.shop.name)+'</div></div>'};
function discover(){const P=liveP().filter(p=>p.stock>0),sd=sold(),out=[];
  const tr=P.slice().sort((a,b)=>(b.ft?1:0)-(a.ft?1:0)||(sd[b.id]||0)-(sd[a.id]||0)||(b.dis/b.price)-(a.dis/a.price)).slice(0,10);out.push(strip('🔥 '+L('ट्रेन्डिङ सामान','Trending products'),tr.map(pcard)));
  const dc=P.filter(p=>p.dis>0).sort((a,b)=>b.dis/b.price-a.dis/a.price).slice(0,10);out.push(strip('💸 '+L('छुट अफर','Discount offers'),dc.map(pcard)));
  const sh=live().map(s=>({s,r:rating(s),o:DB.orders.filter(o=>o.mid==s.id).length})).sort((a,b)=>((b.r?b.r.a*Math.log(b.r.n+1.5):0)+b.o*.1)-((a.r?a.r.a*Math.log(a.r.n+1.5):0)+a.o*.1)||near(a.s)-near(b.s)).slice(0,10);
  out.push(strip('🏪 '+L('लोकप्रिय पसल','Popular shops'),sh.map(x=>'<div class="xc" onclick="S.sid='+x.s.id+';S.sub=\'shop\';R()"><b>'+E(x.s.shop.name)+'</b><div class="st" style="text-transform:none">'+E(x.s.local||x.s.dist||'')+kmT(x.s)+'</div>'+(x.r?'<span class="bd Y">'+stars(x.r)+'</span>':'')+'</div>')));
  const cats=new Set();DB.orders.filter(o=>o.cid==S.u.id).forEach(o=>{const s=U(o.mid);if(s&&s.shop)cats.add(s.shop.cat)});
  const rc=P.filter(p=>!cats.size||cats.has(U(p.mid).shop.cat)).sort((a,b)=>near(U(a.mid))-near(U(b.mid))||b.dis/b.price-a.dis/a.price).slice(0,10);out.push(strip('🤖 '+L('तपाईंका लागि सिफारिस','Recommended for you'),rc.map(pcard)));
  const fl=X().fl,fp=P.filter(p=>has(fl,p.mid)).slice(0,10);out.push(strip('➕ '+L('फलो गरेका पसलबाट','From shops you follow'),fp.map(pcard)));
  return out.filter(Boolean)}

/* ================= Shop page panel ================= */
function shopPanel(){const s=U(S.sid);if(!s||!s.shop)return null;const x=X(),r=rating(s),su=shopUid(s),rv=(RV[su]&&RV[su].list||[]).slice(0,5);const d=document.createElement('div');d.id='xshop';d.className='xp';
  d.innerHTML=(hol(s)?'<div class="bd Y" style="display:block;margin-bottom:6px">🏖️ '+L('यो पसल बिदामा छ','This shop is on holiday')+(s.shop.hol.msg?' — '+E(s.shop.hol.msg):'')+'</div>':'')+
  '<div class="row"><b>'+(r?stars(r):'⭐ '+L('रेटिङ छैन','No ratings yet'))+'</b></div><div class="row2">'+
  '<button class="btn sm g" onclick="xSaveS('+s.id+')">'+(has(x.sv.s,s.id)?'❤️ ':'🤍 ')+L('सुरक्षित','Save')+'</button>'+
  '<button class="btn sm g" onclick="xFollow('+s.id+')">'+(has(x.fl,s.id)?'✅ '+L('फलो गरियो','Following'):'➕ '+L('फलो','Follow'))+'</button>'+
  (s._uid?'<button class="btn sm s" onclick="obChat(\''+s._uid+'\',\''+E(s.shop.name).replace(/'/g,'')+'\')">💬 '+L('सन्देश / कल','Message / Call')+'</button>':'')+'<button class="btn sm g" onclick="xShare('+s.id+')">📤 '+L('सेयर','Share')+'</button>'+
  (canRate(s)?'<button class="btn sm s" onclick="xRate('+s.id+')">⭐ '+L('रेटिङ दिनुहोस्','Rate')+'</button>':'')+
  '<button class="btn sm r" onclick="if(confirm(\''+L('यो पसल ब्लक गर्ने?','Block this shop?')+'\'))xBlock('+s.id+')">🚫 '+L('ब्लक','Block')+'</button></div>'+
  (rv.length?'<div style="margin-top:8px">'+rv.map(v=>'<div class="st" style="text-transform:none;margin:4px 0">'+'★'.repeat(v.r)+' <b>'+E(v.n||'')+'</b> '+E(v.t||'')+'</div>').join('')+'</div>':'');return d}

/* ================= Order tracking, address on order, rate shortcut ================= */
const STEPS=['Pending','Processing','Packed','Shipped','Delivered'],SN={Pending:['अर्डर गरियो','Order placed'],Processing:['पसलले स्वीकार गर्‍यो','Accepted by shop'],Packed:['प्याक भयो','Packed'],Shipped:['डेलिभरीमा','Out for delivery'],Delivered:['डेलिभर भयो','Delivered']};
window.xTrack=id=>{const o=DB.orders.find(x=>x.id==id);if(!o)return;const tl=o.tl||[],ci=STEPS.indexOf(o.st),tm=s=>{const t=tl.find(x=>x.s==s);return t?' <span class="st">'+new Date(t.t).toLocaleString()+'</span>':s=='Pending'?' <span class="st">'+E(o.d)+'</span>':''};
  modal('<h2>📍 '+L('अर्डर ट्र्याकिङ','Order tracking')+' #'+o.id+'</h2>'+(o.st=='Cancelled'?'<div class="bd R">'+L('रद्द भयो','Cancelled')+'</div>':'<div class="xtl">'+STEPS.map((s,i)=>'<div class="'+(i<=ci?'d':'')+'"><b>'+SN[s][ne()?0:1]+'</b>'+(i<=ci?tm(s):'')+'</div>').join('')+(o.rcv?'<div class="d"><b>'+L('ग्राहकले पायो','Received by customer')+'</b> <span class="st">'+E(o.rcv)+'</span></div>':'')+'</div>')+(o.ad?'<div class="c">📍 '+E(o.ad)+'</div>':''))};
const _setO=window.setO;if(typeof _setO=='function')window.setO=function(id,s){const o=DB.orders.find(x=>x.id==id),b=o&&o.st,r=_setO.apply(this,arguments);try{if(o&&o.st!==b){o.tl=o.tl||[];o.tl.push({s:o.st,t:Date.now()});save()}}catch(_){}return r};
const _oCard=window.oCard;if(typeof _oCard=='function')window.oCard=function(o,m){let h=_oCard.apply(this,arguments);try{
  if(o.ad&&role()!='c')h=h.replace('<div class="st" style="margin:5px 0">','<div class="st" style="margin:5px 0;text-transform:none">📍 '+E(o.ad)+'</div><div class="st" style="margin:5px 0">');
  const ex='<button class="btn sm g" onclick="xTrack('+o.id+')">📍 '+L('ट्र्याक','Track')+'</button>'+(role()=='c'&&o.st=='Delivered'?'<button class="btn sm g" onclick="xRate('+o.mid+')">⭐ '+L('रेटिङ','Rate')+'</button>':'');
  const k=h.lastIndexOf('</div></div>');if(k>-1)h=h.slice(0,k)+ex+h.slice(k)}catch(_){}return h};
const _co=window.checkout;if(typeof _co=='function')window.checkout=function(){const sel=document.getElementById('xad'),a=sel&&X().ad.find(x=>String(x.id)===sel.value),ids=new Set(DB.orders.map(o=>o.id)),r=_co.apply(this,arguments);
  try{if(a){let c=0;DB.orders.forEach(o=>{if(!ids.has(o.id)&&o.cid==S.u.id){o.ad=a.l+': '+a.t;c++}});if(c)save()}}catch(_){}return r};

/* ================= Customer screens ================= */
const SVX={};
SVX.xsave=()=>{const x=X(),sh=x.sv.s.map(U).filter(s=>s&&s.shop),pr=x.sv.p.map(i=>DB.products.find(p=>p.id==i)).filter(Boolean);
  return '<h3>❤️ '+L('सुरक्षित पसल','Saved shops')+'</h3>'+(sh.map(s=>'<div class="c row"><b style="cursor:pointer" onclick="S.sid='+s.id+';S.sub=\'shop\';R()">🏪 '+E(s.shop.name)+'</b><button class="btn sm r" onclick="xSaveS('+s.id+')">✕</button></div>').join('')||empty())+'<h3>❤️ '+L('सुरक्षित सामान','Saved products')+'</h3>'+(pr.map(p=>pc(p)).join('')||empty())};
SVX.xblk=()=>{const sh=X().bk.map(U).filter(s=>s&&s.shop);return '<h3>🚫 '+L('ब्लक गरिएका पसल','Blocked shops')+'</h3>'+(sh.map(s=>'<div class="c row"><b>'+E(s.shop.name)+'</b><button class="btn sm g" onclick="xBlock('+s.id+')">'+L('अनब्लक','Unblock')+'</button></div>').join('')||empty())};
SVX.xloy=()=>{const p=S.u.pts||0,tier=p>=2000?'Gold':p>=500?'Silver':'Bronze',nx=p>=2000?0:p>=500?2000:500;return '<h3>🪙 '+L('लोयल्टी पोइन्ट','Loyalty points')+'</h3><div class="c"><div class="big">'+p+'</div><span class="bd Y">'+tier+'</span>'+(nx?'<div class="st" style="text-transform:none;margin-top:6px">'+L('अर्को तहसम्म','To next tier')+': '+(nx-p)+'</div>':'')+'<div class="st" style="text-transform:none;margin-top:6px">'+L('प्रत्येक रु १०० खरिदमा १० पोइन्ट','10 points for every Rs 100 spent')+'</div></div><h3>'+L('इतिहास','History')+'</h3>'+(DB.ph.filter(h=>h.u==S.u.id).map(h=>'<div class="c row"><span>'+E(h.t)+'<div class="st">'+h.d+'</div></span><b>'+(h.a<0?'':'+')+rs(h.a)+'</b></div>').join('')||empty())};
SVX.xaddr=()=>{const x=X();return '<h3>📍 '+L('ठेगाना व्यवस्थापन','Address management')+'</h3>'+(x.ad.map(a=>'<div class="c"><div class="row"><b>'+E(a.l)+(a.d?' <span class="bd G">'+L('डिफल्ट','Default')+'</span>':'')+'</b><span><button class="btn sm g" onclick="xAdDef('+a.id+')">★</button> <button class="btn sm r" onclick="xAdDel('+a.id+')">✕</button></span></div><div class="st" style="text-transform:none">'+E(a.t)+'</div></div>').join('')||empty())+
  '<div class="xp"><input class="xin" id="xa_l" maxlength="30" placeholder="'+L('नाम (घर, अफिस...)','Label (Home, Office...)')+'"><input class="xin" id="xa_t" maxlength="120" placeholder="'+L('ठेगाना / ल्यान्डमार्क','Address / landmark')+'"><button style="'+BTN+'" onclick="xAdAdd()">＋ '+L('थप्नुहोस्','Add')+'</button></div>'};
window.xAdAdd=()=>{const l=document.getElementById('xa_l').value.trim(),t=document.getElementById('xa_t').value.trim();if(!l||!t)return toast(L('नाम र ठेगाना लेख्नुहोस्','Enter label and address'));const x=X();if(x.ad.length>=8)return toast(L('अधिकतम ८','Max 8'));x.ad.push({id:Date.now(),l:l.slice(0,30),t:t.slice(0,120),d:x.ad.length?0:1});save();R()};
window.xAdDel=id=>{const x=X();x.ad=x.ad.filter(a=>a.id!=id);if(x.ad.length&&!x.ad.some(a=>a.d))x.ad[0].d=1;save();R()};
window.xAdDef=id=>{X().ad.forEach(a=>a.d=a.id==id?1:0);save();R()};
/* Smart tools: cheapest finder + comparison */
const AI={q:'',cmp:[]};
const rowsAI=()=>{const q=AI.q.trim().toLowerCase();if(!q)return '<div class="c st">'+L('सामानको नाम लेख्नुहोस्','Type a product name')+'</div>';
  const R0=liveP().filter(p=>(p.name+' '+(p.type||'')).toLowerCase().includes(q)).sort((a,b)=>eff(a)-eff(b)).slice(0,12);
  return R0.map((p,i)=>{const s=U(p.mid);return '<div class="c row"><span><b>'+(i==0?'🏆 ':'')+E(p.name)+'</b><div class="st" style="text-transform:none">'+E(s.shop.name)+kmT(s)+(p.stock<=0?' · '+T('Out of stock'):'')+'</div></span><span style="text-align:right"><b style="color:var(--saf)">'+rs(eff(p))+'</b><br><button class="btn sm g" onclick="xCmp('+p.id+')">'+(has(AI.cmp,p.id)?'✓ ':'')+'⚖️</button></span></div>'}).join('')||'<div class="c st">'+T('No products found')+'</div>'};
const cmpAI=()=>{const P=AI.cmp.map(i=>DB.products.find(p=>p.id==i)).filter(Boolean);if(P.length<2)return '<div class="st" style="text-transform:none">'+L('तुलना गर्न २-३ सामानमा ⚖️ थिच्नुहोस्','Tap ⚖️ on 2–3 products to compare')+'</div>';
  const best=Math.min(...P.map(eff)),r=[[L('सामान','Product'),p=>E(p.name)],[L('पसल','Shop'),p=>E(U(p.mid).shop.name)],[L('मूल्य','Price'),p=>(eff(p)==best?'🏆 ':'')+rs(eff(p))],[L('छुट','Discount'),p=>p.dis?'-'+Math.round(p.dis/p.price*100)+'%':'—'],[L('दूरी','Distance'),p=>kmT(U(p.mid)).replace(' · ','')||'—'],[L('रेटिङ','Rating'),p=>{const x=rating(U(p.mid));return x?stars(x):'—'}],[L('स्टक','Stock'),p=>p.stock>0?p.stock:T('Out of stock')]];
  return '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13px">'+r.map(x=>'<tr><td style="padding:6px;border-bottom:1px solid var(--ln);font-weight:700">'+x[0]+'</td>'+P.map(p=>'<td style="padding:6px;border-bottom:1px solid var(--ln)">'+x[1](p)+'</td>').join('')+'</tr>').join('')+'</table></div><button class="btn sm g" style="margin-top:6px" onclick="AIclr()">'+L('खाली गर्नुहोस्','Clear')+'</button>'};
SVX.xai=()=>'<h3>🔎 '+L('स्मार्ट सामान खोजी','Smart product finder')+'</h3><input class="xin" id="xai_q" placeholder="'+L('जस्तै: चिया, जुत्ता','e.g. tea, shoes')+'" value="'+E(AI.q)+'" oninput="AIq(this.value)"><div class="st" style="text-transform:none">'+L('सबैभन्दा सस्तो पहिले, नजिकको पसल सहित','Cheapest first, with shop distance')+'</div><div id="xai_r">'+rowsAI()+'</div><h3>⚖️ '+L('तुलना','Comparison')+'</h3><div id="xai_c">'+cmpAI()+'</div>';
window.AIq=v=>{AI.q=v;document.getElementById('xai_r').innerHTML=rowsAI()};
window.xCmp=id=>{const k=AI.cmp.indexOf(id);if(k>=0)AI.cmp.splice(k,1);else{if(AI.cmp.length>=3)AI.cmp.shift();AI.cmp.push(id)}document.getElementById('xai_r').innerHTML=rowsAI();document.getElementById('xai_c').innerHTML=cmpAI()};
window.AIclr=()=>{AI.cmp=[];R()};
/* Call history */
window.xCalls=async function(){const me=au(),f=fsx();if(!me||!f)return toast(L('क्लाउड जोडिएको छैन','Cloud not connected'));const w=modal('<h2>📞 '+L('कल इतिहास','Call history')+'</h2><div id="xcl">…</div>');
  try{const [a,b]=await Promise.all([f.collection('calls').where('from','==',me.uid).limit(50).get(),f.collection('calls').where('to','==',me.uid).limit(50).get()]),L0=[];
    a.forEach(d=>L0.push({o:1,...d.data()}));b.forEach(d=>L0.push({o:0,...d.data()}));L0.sort((p,q)=>(q.ts||0)-(p.ts||0));
    const cn={};await Promise.all([...new Set(L0.filter(x=>x.o&&x.cid).map(x=>x.cid))].slice(0,20).map(async c=>{try{const d=await f.collection('chats').doc(c).get();if(d.exists){const n=d.data().names||{};cn[c]=n}}catch(_){}}));
    const st={end:L('सम्पन्न','Ended'),rej:L('अस्वीकृत','Declined'),ring:L('नउठाइएको','Missed'),ans:L('उठाइयो','Answered')};
    w.querySelector('#xcl').innerHTML=L0.map(x=>{let nm=x.fn||'?';if(x.o){const n=cn[x.cid]||{};nm=n[x.to]||'?'}return '<div class="c row"><span>'+(x.o?'📤':'📥')+(x.v?'🎥':'📞')+' <b>'+E(nm)+'</b><div class="st">'+new Date(x.ts||0).toLocaleString()+'</div></span><span class="bd">'+(st[x.st]||E(x.st||''))+'</span></div>'}).join('')||empty()}
  catch(e){w.querySelector('#xcl').textContent='Error: '+(e.code||e)}};

/* ================= Merchant screens ================= */
const myOrders=()=>DB.orders.filter(o=>o.mid==S.u.id),myProds=()=>DB.products.filter(p=>p.mid==S.u.id);
const dstr=n=>{const d=new Date();d.setDate(d.getDate()-n);return d.toISOString().slice(0,10)};
SVX.xins=()=>{const O=myOrders().filter(o=>o.st=='Delivered'),days=[...Array(7)].map((_,i)=>dstr(6-i)),by=d=>O.filter(o=>o.d==d).reduce((s,o)=>s+o.total,0),vals=days.map(by),mx=Math.max(1,...vals),
  td=by(today()),mo=O.filter(o=>o.d.slice(0,7)==today().slice(0,7)).reduce((s,o)=>s+o.total,0),cu=new Set(myOrders().map(o=>o.cid)).size,rt=rating(S.u);
  const qty=(from,to)=>{const m={};myOrders().filter(o=>o.st!='Cancelled'&&o.d>=from&&o.d<=to).forEach(o=>o.items.forEach(i=>m[i.pid]=(m[i.pid]||0)+i.q));return m},a1=qty(dstr(13),today()),a0=qty(dstr(27),dstr(14)),a30=qty(dstr(29),today());
  const P=myProds(),best=P.map(p=>({p,q:a30[p.id]||0})).sort((a,b)=>b.q-a.q).filter(x=>x.q).slice(0,5);
  const al=P.map(p=>{const dl=(a30[p.id]||0)/30,days=dl>0?Math.floor(p.stock/dl):null;return {p,days}}).filter(x=>x.p.stock<10||(x.days!==null&&x.days<7)).slice(0,8);
  const dm=P.map(p=>({p,n:Math.round((a1[p.id]||0)/14*7),t:(a1[p.id]||0)-(a0[p.id]||0)})).filter(x=>x.n>0).sort((a,b)=>b.n-a.n).slice(0,5);
  const ps=P.map(p=>{const C=liveP().filter(q=>q.mid!=S.u.id&&q.type&&q.type==p.type).map(eff).sort((a,b)=>a-b);if(C.length<2)return null;const md=C[C.length>>1],e=eff(p);return Math.abs(e-md)/md>.2?{p,md,e}:null}).filter(Boolean).slice(0,5);
  const tips=[];if(!P.some(p=>p.dis>0))tips.push(L('केही सामानमा छुट राख्नुहोस् — छुट अफरमा देखिन्छ','Add a discount to some items — they appear in Discount offers'));if(!(S.u.vl||[]).length)tips.push(L('भिडियो लिङ्क थप्नुहोस्','Add a video link to attract customers'));if(!P.some(p=>p.ft))tips.push(L('मुख्य सामानलाई ⭐ फिचर्ड बनाउनुहोस्','Mark your best item ⭐ Featured'));if(rt&&rt.a<4)tips.push(L('रेटिङ सुधार्न छिटो डेलिभरी र सन्देशको जवाफ दिनुहोस्','Improve your rating with faster delivery and replies'));if(!tips.length)tips.push(L('राम्रो चलिरहेको छ — नियमित स्टक अपडेट गर्नुहोस्','Going well — keep stock updated'));
  return '<h3>📊 '+L('व्यापार इनसाइट','Business insights')+'</h3><div class="g2">'+stat('Today',rs(td))+stat('Monthly',rs(mo))+stat(L('ग्राहक','Customers'),cu)+stat('Rating',rt?stars(rt):'—')+'</div><div class="c"><b>'+L('७ दिनको आम्दानी','Last 7 days earnings')+'</b><div class="xbar">'+vals.map((v,i)=>'<i style="height:'+Math.round(v/mx*100)+'%" title="'+rs(v)+'"><span>'+days[i].slice(8)+'</span></i>').join('')+'</div><div style="height:14px"></div></div>'+
  '<h3>🏆 '+T('Best sellers')+'</h3>'+(best.map(x=>'<div class="c row"><b>'+E(x.p.name)+'</b><span>'+x.q+' '+T('units')+'</span></div>').join('')||empty())+
  '<h3>⚠️ '+L('स्टक अलर्ट','Stock alert')+'</h3>'+(al.map(x=>'<div class="c row"><b>'+E(x.p.name)+'</b><span class="bd '+(x.p.stock<=0?'R':'Y')+'">'+x.p.stock+(x.days!==null?' · ~'+x.days+L(' दिन',' days'):'')+'</span></div>').join('')||'<div class="c st">'+T('Stock levels healthy.')+'</div>')+
  '<h3>📈 '+L('मागको अनुमान (अर्को ७ दिन)','Demand prediction (next 7 days)')+'</h3>'+(dm.map(x=>'<div class="c row"><b>'+E(x.p.name)+'</b><span>~'+x.n+' '+T('units')+' '+(x.t>0?'↗':x.t<0?'↘':'→')+'</span></div>').join('')||'<div class="c st">'+L('अर्डर डाटा पर्याप्त छैन','Not enough order data yet')+'</div>')+
  '<h3>💰 '+L('मूल्य सुझाव','Price suggestion')+'</h3>'+(ps.map(x=>'<div class="c"><b>'+E(x.p.name)+'</b><div class="st" style="text-transform:none">'+L('तपाईंको','Yours')+' '+rs(x.e)+' · '+L('बजार मध्यम','Market median')+' '+rs(x.md)+' → '+(x.e>x.md?L('घटाउने विचार गर्नुहोस्','consider lowering'):L('बढाउन सकिन्छ','room to raise'))+'</div></div>').join('')||'<div class="c st">'+L('तुलना गर्न पर्याप्त डाटा छैन','Not enough comparable items')+'</div>')+
  '<h3>💡 '+L('मार्केटिङ सुझाव','Marketing tips')+'</h3>'+tips.map(t=>'<div class="c">'+t+'</div>').join('')};
SVX.xhol=()=>{const h=S.u.shop.hol||{};return '<h3>🏖️ '+L('बिदा सेटिङ','Holiday settings')+'</h3><div class="xp"><label><input type="checkbox" id="xh_on" '+(h.on?'checked':'')+'> '+L('पसल बिदामा (ग्राहकले अर्डर गर्न सक्दैनन्)','Shop on holiday (customers cannot add to cart)')+'</label><div class="g2"><div><div class="st">'+L('देखि','From')+'</div><input class="xin" type="date" id="xh_f" value="'+E(h.from||'')+'"></div><div><div class="st">'+L('सम्म','To')+'</div><input class="xin" type="date" id="xh_t" value="'+E(h.to||'')+'"></div></div><input class="xin" id="xh_m" maxlength="80" placeholder="'+L('सन्देश (ऐच्छिक)','Message (optional)')+'" value="'+E(h.msg||'')+'"><button style="'+BTN+'" onclick="xHolSave()">'+L('सेभ','Save')+'</button></div>'};
window.xHolSave=()=>{const g=i=>document.getElementById(i);S.u.shop.hol={on:g('xh_on').checked?1:0,from:g('xh_f').value,to:g('xh_t').value,msg:g('xh_m').value.trim().slice(0,80)};save();toast('✅');R()};
SVX.xprod=()=>'<h3>⭐ '+L('फिचर्ड र स्टक','Featured & stock')+'</h3>'+(myProds().map(p=>'<div class="c"><div class="row"><b>'+(p.ft?'⭐ ':'')+E(p.name)+'</b><span class="bd '+(p.stock<=0?'R':'G')+'">'+p.stock+'</span></div><div class="row2" style="display:flex;gap:6px;margin-top:6px"><button class="btn sm g" onclick="xFeat('+p.id+')">'+(p.ft?L('फिचर्ड हटाउनुहोस्','Unfeature'):'⭐ '+L('फिचर्ड','Feature'))+'</button><button class="btn sm '+(p.stock<=0?'j':'r')+'" onclick="xOos('+p.id+')">'+(p.stock<=0?L('स्टक फर्काउनुहोस्','Restore stock'):'⛔ '+T('Out of stock'))+'</button></div></div>').join('')||empty());
window.xFeat=id=>{const p=DB.products.find(x=>x.id==id&&x.mid==S.u.id);if(!p)return;if(p.ft)delete p.ft;else{if(myProds().filter(x=>x.ft).length>=5)return toast(L('अधिकतम ५ फिचर्ड','Max 5 featured'));p.ft=1}save();R()};
window.xOos=id=>{const p=DB.products.find(x=>x.id==id&&x.mid==S.u.id);if(!p)return;if(p.stock>0){p.ps=p.stock;p.stock=0}else{p.stock=p.ps||1;delete p.ps}save();R()};
SVX.xqr=()=>{const q=X().qr;return '<h3>💬 '+L('छिटो जवाफ','Quick replies')+'</h3>'+(q.map((t,i)=>'<div class="c row"><span>'+E(t)+'</span><button class="btn sm r" onclick="xQrDel('+i+')">✕</button></div>').join('')||empty())+'<div class="xp"><input class="xin" id="xq_t" maxlength="80" placeholder="'+L('जस्तै: सामान उपलब्ध छ।','e.g. Yes, it is available.')+'"><button style="'+BTN+'" onclick="xQrAdd()">＋</button></div><div class="st" style="text-transform:none">'+L('च्याटमा यी बटनका रूपमा देखिन्छन्।','They appear as buttons inside chat.')+'</div>'};
window.xQrAdd=()=>{const v=document.getElementById('xq_t').value.trim(),q=X().qr;if(!v)return;if(q.length>=6)return toast(L('अधिकतम ६','Max 6'));q.push(v.slice(0,80));save();R()};
window.xQrDel=i=>{X().qr.splice(i,1);save();R()};
const kdue=k=>k.amt-k.paid;
SVX.xkh=()=>{const K=DB.khata.filter(k=>k.mid==S.u.id);return '<h3>📒 '+L('खाता रिमाइन्डर र रिपोर्ट','Khata reminders & report')+'</h3><button style="'+BTN+';margin-bottom:8px" onclick="xKhCsv()">⬇️ '+L('खाता रिपोर्ट (CSV)','Export khata report (CSV)')+'</button>'+(K.map(k=>'<div class="c"><div class="row"><b>'+E(k.name)+'</b><b style="color:var(--crim,#c62828)">'+rs(kdue(k))+'</b></div><div class="st" style="text-transform:none">'+E(k.note||'')+'</div>'+(kdue(k)>0?'<button class="btn sm s" style="margin-top:6px" onclick="xKhRem('+k.id+')">📤 '+L('भुक्तानी रिमाइन्डर','Send reminder')+'</button>':'<span class="bd G">'+T('Paid')+'</span>')+'</div>').join('')||empty())};
window.xKhRem=id=>{const k=DB.khata.find(x=>x.id==id&&x.mid==S.u.id);if(!k)return;const t=L('नमस्ते '+k.name+', '+S.u.shop.name+' मा तपाईंको बाँकी रकम '+rs(kdue(k))+' छ। कृपया भुक्तानी गरिदिनुहोला। धन्यवाद।','Hello '+k.name+', your balance due at '+S.u.shop.name+' is '+rs(kdue(k))+'. Please pay when convenient. Thank you.');
  const lu=DB.users.find(u=>u.role=='c'&&u.name&&u.name.toLowerCase()==k.name.toLowerCase());try{lu&&nfu(lu.id,'📒 '+t)}catch(_){}
  if(navigator.share)navigator.share({text:t}).catch(()=>{});else if(navigator.clipboard)navigator.clipboard.writeText(t).then(()=>toast(L('कपी भयो — SMS/च्याटमा टाँस्नुहोस्','Copied — paste into SMS/chat')))};
window.xKhCsv=()=>{const K=DB.khata.filter(k=>k.mid==S.u.id),q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"',c=[['name','amount','paid','due','note'].join(',')].concat(K.map(k=>[q(k.name),k.amt,k.paid,kdue(k),q(k.note)].join(','))).join('\n'),
  a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['﻿'+c],{type:'text/csv'}));a.download='khata-'+today()+'.csv';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)};
/* Quick replies inside chat (merchant) */
new MutationObserver(()=>{try{const i=document.getElementById('mi');if(!i||role()!='m'||document.getElementById('xqb')||!X().qr.length)return;const b=document.createElement('div');b.id='xqb';b.style.cssText='display:flex;gap:6px;overflow-x:auto;padding:6px 8px 0';
  b.innerHTML=X().qr.map((t,k)=>'<button data-k="'+k+'" style="'+BTN+';white-space:nowrap;font-weight:600;background:#546e7a">'+E(t)+'</button>').join('');b.onclick=e=>{const k=e.target.dataset&&e.target.dataset.k;if(k!=null){i.value=X().qr[k];i.focus()}};i.parentNode.parentNode.insertBefore(b,i.parentNode)}catch(_){}}).observe(document.body,{childList:true,subtree:true});

/* ================= Admin: fraud & risk heuristics ================= */
SVX.xfr=()=>{const out=[],P=DB.pay,seen={};P.forEach(p=>{const k=(p.ref||'').trim().toLowerCase();if(k.length<6)return;(seen[k]=seen[k]||[]).push(p)});
  Object.entries(seen).filter(([,v])=>v.length>1).forEach(([k,v])=>out.push(['🔁',L('दोहोरिएको ट्रान्जेक्सन आईडी','Duplicate transaction ID'),k+' × '+v.length]));
  const pan={};shops().forEach(s=>{const k=s.shop.pan;if(k)(pan[k]=pan[k]||[]).push(s.shop.name)});Object.entries(pan).filter(([,v])=>v.length>1).forEach(([k,v])=>out.push(['🪪',L('एउटै PAN भएका पसल','Shops sharing one PAN'),k+': '+v.join(', ')]));
  const byT={};DB.products.forEach(p=>{if(p.type)(byT[p.type]=byT[p.type]||[]).push(p)});Object.values(byT).forEach(L1=>{if(L1.length<4)return;const e=L1.map(eff).sort((a,b)=>a-b),md=e[e.length>>1];L1.forEach(p=>{const x=eff(p);if(md>0&&(x<md*.3||x>md*3))out.push(['💲',L('असामान्य मूल्य','Unusual price'),p.name+' — '+rs(x)+' ('+L('मध्यम','median')+' '+rs(md)+')'])})});
  const cc={};DB.orders.filter(o=>o.st=='Cancelled').forEach(o=>cc[o.cid]=(cc[o.cid]||0)+1);Object.entries(cc).filter(([,n])=>n>=3).forEach(([id,n])=>out.push(['🚫',L('धेरै रद्द अर्डर','Many cancelled orders'),(U(id)&&U(id).name||id)+' × '+n]));
  const mc={};DB.comp.forEach(c=>mc[c.mid]=(mc[c.mid]||0)+1);Object.entries(mc).filter(([,n])=>n>=2).forEach(([id,n])=>out.push(['⚖️',L('बारम्बार उजुरी','Repeated complaints'),(U(id)&&U(id).shop&&U(id).shop.name||id)+' × '+n]));
  shops().filter(s=>s.shop.fake).forEach(s=>out.push(['⛔',L('नक्कली चिन्ह लगाइएको','Marked fake'),s.shop.name]));
  return '<h3>🛡️ '+L('जोखिम र ठगी जाँच','Fraud & risk check')+'</h3><div class="st" style="text-transform:none;margin-bottom:6px">'+L('यो स्वचालित संकेत मात्र हो — निर्णय प्रशासकले गर्नुपर्छ।','Automatic signals only — an admin must decide.')+'</div>'+(out.map(r=>'<div class="c"><b>'+r[0]+' '+E(r[1])+'</b><div class="st" style="text-transform:none">'+E(r[2])+'</div></div>').join('')||'<div class="c st">✅ '+L('कुनै संकेत भेटिएन','No signals found')+'</div>')};

/* register screens in the existing SV map (adds keys only) */
if(typeof SV=='object')Object.assign(SV,SVX);

/* ================= DOM decoration (runs after every R) ================= */
function decorate(){['xfilter','xdisc','xshop','xextra'].forEach(i=>{const e=document.getElementById(i);if(e)e.remove()});
  if(typeof S==='undefined'||!S.u||typeof DB==='undefined'||!DB)return;const m=document.querySelector('.main');if(!m)return;const r=role();
  if(r=='c'&&S.tab=='home'&&!S.sub){const anchor=document.getElementById('catchips')||document.getElementById('trust');
    const f=document.createDocumentFragment(),fb=filterBox();f.appendChild(fb);
    if(!S.q.trim()&&!S.g&&!fon()){const dv=document.createElement('div');dv.id='xdisc';discover().forEach(x=>dv.appendChild(x));f.appendChild(dv)}
    anchor?anchor.parentNode.insertBefore(f,anchor.nextSibling):m.insertBefore(f,m.firstChild)}
  if(r=='c'&&S.sub=='shop'&&S.sid){const p=shopPanel();if(p){const b=m.querySelector('button.btn');b?b.parentNode.insertBefore(p,b.nextSibling):m.insertBefore(p,m.firstChild)}}
  if(r=='c'&&S.tab=='sel'&&S.sel=='cart'&&!S.sub){const pay=document.getElementById('pay'),A=X().ad;if(pay&&A.length&&!document.getElementById('xad')){const s=document.createElement('select');s.id='xad';s.className='inp';s.style.marginTop='10px';s.innerHTML=A.map(a=>'<option value="'+a.id+'"'+(a.d?' selected':'')+'>📍 '+E(a.l)+' — '+E(a.t)+'</option>').join('');pay.parentNode.insertBefore(s,pay)}}
  if(r=='c'&&S.tab=='me'&&!S.sub){const d=document.createElement('div');d.id='xextra';d.innerHTML='<div class="c row" style="cursor:pointer" onclick="obMsgs()"><span>💬 <b>'+L('मेसेन्जर (सन्देश, कल, समूह)','Messenger (chat, calls, groups)')+'</b></span><b>›</b></div>'+lkx('xsave','❤️',L('सुरक्षित पसल र सामान','Saved shops & products'))+lkx('xaddr','📍',L('ठेगाना व्यवस्थापन','Address management'))+lkx('xloy','🪙',L('लोयल्टी पोइन्ट','Loyalty points'))+lkx('xai','🔎',L('स्मार्ट खोजी / तुलना','Smart finder & compare'))+lkx('xblk','🚫',L('ब्लक गरिएका पसल','Blocked shops'))+'<div class="c row" style="cursor:pointer" onclick="xCalls()"><span>📞 <b>'+L('कल इतिहास','Call history')+'</b></span><b>›</b></div>';
    const pl=document.getElementById('plinks');pl?m.insertBefore(d,pl):m.appendChild(d)}
  if(r=='m'&&S.tab=='more'&&!S.sub&&S.u.shop){const d=document.createElement('div');d.id='xextra';d.innerHTML='<div class="c row" style="cursor:pointer" onclick="obMsgs()"><span>💬 <b>'+L('मेसेन्जर (सन्देश, कल, समूह)','Messenger (chat, calls, groups)')+'</b></span><b>›</b></div>'+lkx('xins','📊',L('व्यापार इनसाइट (AI)','Business insights (AI)'))+lkx('xprod','⭐',L('फिचर्ड र स्टक','Featured & stock'))+lkx('xhol','🏖️',L('बिदा सेटिङ','Holiday settings'))+lkx('xqr','💬',L('छिटो जवाफ','Quick replies'))+lkx('xkh','📒',L('खाता रिमाइन्डर / रिपोर्ट','Khata reminders / report'))+'<div class="c row" style="cursor:pointer" onclick="xCalls()"><span>📞 <b>'+L('कल इतिहास','Call history')+'</b></span><b>›</b></div>';m.appendChild(d)}
  if(r=='a'&&S.tab=='more'&&!S.sub){const d=document.createElement('div');d.id='xextra';d.innerHTML=lkx('xfr','🛡️',L('जोखिम र ठगी जाँच','Fraud & risk check'));m.appendChild(d)}
  if(r=='m'&&S.sub=='ana'){m.querySelectorAll('.big').forEach(e=>{if(/^4\.8/.test(e.textContent.trim())){const x=rating(S.u);e.textContent=x?stars(x):'—'}})}}
const _R=window.R;if(typeof _R!=='function')return;
window.R=function(){const r=_R.apply(this,arguments);try{decorate()}catch(e){console.warn('ext',e)}return r};
setTimeout(()=>{try{if(S.u){loadRV();R()}}catch(_){}},900);
setInterval(()=>{if(S.u)loadRV()},120000);
const _sess=window.sess;if(typeof _sess=='function')window.sess=function(){const r=_sess.apply(this,arguments);setTimeout(loadRV,4000);return r};
})();
