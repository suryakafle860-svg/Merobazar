/* Mero Bazar layout: compact product cards, side bar (settings) and background colors. Adds only; app.js is untouched. */
(function(){
const ne=()=>(window.DB&&DB.lang)=='ne',KB='mb_bg';
const PAL=[['0','',''],['g','#E8F5EE','#0D2A1E'],['b','#E6F1FB','#0A2238'],['o','#FFF1E3','#2E1D0C'],['p','#EFEAFB','#1E1636'],['r','#FDEBEF','#2E1019'],['s','#F1F3F6','#161B26']];
const dk=()=>{const t=document.documentElement.dataset.theme;return t=='dark'||(t!='light'&&matchMedia('(prefers-color-scheme: dark)').matches)};
const gk=()=>{try{return localStorage.getItem(KB)||'0'}catch(_){return'0'}};
function applyBg(){const c=PAL.find(x=>x[0]==gk());let s=document.getElementById('mbbg');if(!s){s=document.createElement('style');s.id='mbbg';document.head.appendChild(s)}s.textContent=c&&c[1]?':root{--bg:'+(dk()?c[2]:c[1])+'!important}':''}
new MutationObserver(applyBg).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});applyBg();
window.mbBg=k=>{try{localStorage.setItem(KB,k)}catch(_){}applyBg();mbOpen()};
window.mbClose=()=>{const d=document.getElementById('mbd');if(d)d.classList.remove('on')};
window.mbGo=f=>{mbClose();try{f()}catch(e){console.warn(e)}};
window.mbOpen=function(){const n=ne();let d=document.getElementById('mbd');if(!d){d=document.createElement('div');d.id='mbd';d.onclick=e=>{if(e.target===d)mbClose()};document.body.appendChild(d)}
  const u=window.S&&S.u;if(!u)return;const it=(i,t,f)=>'<button class="it" onclick="mbGo(()=>'+f+')"><span>'+i+'</span>'+t+'</button>';
  d.innerHTML='<div class="pn"><div class="row"><b style="font-size:18px">मेरो बजार</b><button class="btn sm g" onclick="mbClose()">✕</button></div><div class="st" style="margin:4px 0 10px;text-transform:none">'+(u.name||'')+'</div>'+
  it('🏠',n?'गृहपृष्ठ':'Home',"go('home')")+it('👤',u.role=='c'?(n?'मेरो प्रोफाइल':'My profile'):(n?'थप':'More'),"go('"+(u.role=='c'?'me':'more')+"')")+
  it('🌐',n?'English':'नेपाली','lang()')+it('🌓',n?'डार्क / लाइट':'Dark / Light','theme()')+
  '<div class="st" style="margin:12px 8px 2px">🎨 '+(n?'ब्याकग्राउन्ड रङ':'Background color')+'</div><div class="sw">'+PAL.map(c=>'<b onclick="mbBg(\''+c[0]+'\')" style="background:'+(c[1]?(dk()?c[2]:c[1]):'var(--card)')+(gk()==c[0]?';border-color:var(--saf)':'')+'">'+(c[1]?'':'↺')+'</b>').join('')+'</div>'+
  it('🚪',n?'लगआउट':'Logout','logout()')+'</div>';d.classList.add('on')};
const pc0=window.pc;
if(typeof pc0=='function')window.pc=function(p){try{const o=p.stock<=0,s=U(p.mid);
  return '<div class="c pc2">'+pimg(p,s)+'<div class="nm">'+pn(p)+'</div><div class="sn">'+E(s.shop.name)+' · '+E(s.local)+'</div><div><b style="color:var(--saf);font-size:14px">'+rs(eff(p))+'</b> '+(p.dis?'<span class="bd R">-'+Math.round(p.dis/p.price*100)+'%</span>':'')+'</div><div class="ft"><span class="bd '+(o?'R':p.stock<10?'Y':'G')+'">'+(o?T('Out of stock'):p.stock<10?T('Low')+': '+p.stock:T('In stock'))+'</span><button class="btn sm s" '+(o?'disabled style="opacity:.4"':'')+' onclick="add('+p.id+')">＋</button></div></div>'}catch(e){return pc0(p)}};
const R0=window.R;if(typeof R0!=='function')return;
window.R=function(){const r=R0.apply(this,arguments);try{const h=document.querySelector('.hd');if(h&&!h.querySelector('#mbm')){const b=document.createElement('button');b.id='mbm';b.textContent='☰';b.setAttribute('aria-label','Menu');b.onclick=mbOpen;h.insertBefore(b,h.firstChild)}}catch(e){console.warn('layout',e)}return r};
setTimeout(()=>{try{window.S&&S.u&&R()}catch(_){}},700);
})();
