/* Mero Bazar voice calls (1:1, merchant <-> customer, inside a chat). WebRTC + Firestore signalling. Free STUN (Google) + TURN (Metered). */
(function(){
const C=window.MB_CALL||{},ICE=[{urls:'stun:stun.l.google.com:19302'}].concat(C.turn?[{urls:C.turn.urls,username:C.turn.user,credential:C.turn.pass}]:[]);
const ne=()=>(window.DB&&DB.lang)=='ne',me=()=>{try{return firebase.auth().currentUser}catch(_){return null}},db=()=>firebase.firestore();
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tt=(a,b)=>{try{toast(ne()?a:b)}catch(_){}};
let cur=null,ov=null,aud=null,ring=null,inc=null;
const A=()=>{if(!aud){aud=document.createElement('audio');aud.autoplay=true;aud.setAttribute('playsinline','');document.body.appendChild(aud)}return aud};
function beep(on){clearInterval(ring);ring=null;if(!on)return;const go=()=>{try{navigator.vibrate&&navigator.vibrate(300);const x=new(window.AudioContext||window.webkitAudioContext)(),o=x.createOscillator();o.frequency.value=620;o.connect(x.destination);o.start();setTimeout(()=>{o.stop();x.close()},350)}catch(_){}};go();ring=setInterval(go,1800)}
function show(name,st,btns){if(!ov){ov=document.createElement('div');ov.style.cssText='position:fixed;inset:0;z-index:100010;background:linear-gradient(160deg,#1E2B6E,#0F4C9A);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;text-align:center;font-family:inherit';document.body.appendChild(ov)}
  ov.innerHTML='<div style="font-size:64px">📞</div><b style="font-size:22px">'+esc(name)+'</b><div id="cst" style="opacity:.85">'+st+'</div><div style="display:flex;gap:16px;margin-top:20px">'+btns.map((b,i)=>'<button id="cb'+i+'" style="width:68px;height:68px;border-radius:50%;border:0;font-size:26px;background:'+b[1]+';color:#fff">'+b[0]+'</button>').join('')+'</div>';
  btns.forEach((b,i)=>ov.querySelector('#cb'+i).onclick=b[2]);vid()}
function vid(){if(!ov||!cur||!cur.v)return;ov.style.justifyContent='flex-end';const mk=(id,st,s,m)=>{const e=document.createElement('video');e.id=id;e.autoplay=true;e.playsInline=true;e.muted=m;e.style.cssText=st;e.srcObject=s;ov.insertBefore(e,ov.firstChild);e.play().catch(()=>{})};
  if(cur.rs)mk('rv','position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1;background:#000',cur.rs,false);if(cur.stream)mk('lv','position:absolute;top:14px;right:14px;width:96px;height:130px;object-fit:cover;border-radius:12px;border:2px solid #fff;background:#222;transform:scaleX(-1)',cur.stream,true)}
function close(){beep(false);inc=null;if(cur){const c=cur;cur=null;clearTimeout(c.tm);clearInterval(c.tk);c.un.forEach(f=>{try{f()}catch(_){}});try{c.pc.close()}catch(_){}try{c.stream&&c.stream.getTracks().forEach(t=>t.stop())}catch(_){}}
  if(aud)aud.srcObject=null;if(ov){ov.remove();ov=null}}
function hang(st){const c=cur;if(c)c.doc.update({st:st||'end'}).catch(()=>{});close()}
function tick(){const c=cur;if(!c)return;clearInterval(c.tk);c.tk=setInterval(()=>{const e=ov&&ov.querySelector('#cst');if(!e||!c.t0)return;const s=Math.floor((Date.now()-c.t0)/1000);e.textContent=String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')},1000)}
function ctl(name,st){show(name,st,[['🎤','#2e7d32',()=>{if(!cur||!cur.stream)return;cur.mute=!cur.mute;cur.stream.getAudioTracks().forEach(t=>t.enabled=!cur.mute);ov.querySelector('#cb0').textContent=cur.mute?'🔇':'🎤';ov.querySelector('#cb0').style.background=cur.mute?'#757575':'#2e7d32'}],].concat(cur&&cur.v?[['📷','#2e7d32',()=>{if(!cur||!cur.stream)return;cur.cam=!cur.cam;cur.stream.getVideoTracks().forEach(t=>t.enabled=!cur.cam);ov.querySelector('#cb1').style.background=cur.cam?'#757575':'#2e7d32'}]]:[]).concat([['📵','#c62828',()=>hang()]]))}
function mk(doc,caller,name,video){const pc=new RTCPeerConnection({iceServers:ICE}),ice=doc.collection('ice'),q=[],out=[];let rd=false;
  cur={doc,pc,un:[],t0:0,mute:false,stream:null,ready:false,name,v:!!video,rs:null};
  pc.onicecandidate=e=>{if(!e.candidate)return;const o={u:me().uid,c:JSON.stringify(e.candidate)};cur&&cur.ready?ice.add(o).catch(()=>{}):out.push(o)};
  pc.ontrack=e=>{const a=A();a.srcObject=e.streams[0];a.play().catch(()=>{});if(cur&&cur.v&&!cur.rs){cur.rs=e.streams[0];if(ov){const o=ov.querySelector('#rv');if(o)o.remove();vid()}}};
  pc.onconnectionstatechange=()=>{const s=pc.connectionState;if(s=='connected'&&cur){cur.t0=Date.now();clearTimeout(cur.tm);beep(false);ctl(name,'00:00');tick()}else if(s=='failed'){tt('कल जोडिएन। इन्टरनेट जाँच्नुहोस्','Call could not connect. Check your internet.');hang()}};
  cur.flushOut=()=>{cur.ready=true;out.splice(0).forEach(o=>ice.add(o).catch(()=>{}))};
  cur.listen=()=>{cur.un.push(ice.onSnapshot(s=>s.docChanges().forEach(ch=>{if(ch.type!='added')return;const d=ch.doc.data();if(d.u==me().uid)return;const c=JSON.parse(d.c);rd?pc.addIceCandidate(c).catch(()=>{}):q.push(c)})));
    cur.un.push(doc.onSnapshot(s=>{const d=s.data();if(!d||!cur)return;if(caller&&d.answer&&!cur.got){cur.got=1;pc.setRemoteDescription(d.answer).then(()=>{rd=true;q.splice(0).forEach(c=>pc.addIceCandidate(c).catch(()=>{}))})}if(d.st=='end'||d.st=='rej'){if(d.st=='rej'&&caller)tt('कल उठाइएन','Call declined');close()}}))};
  cur.rdy=()=>{rd=true;q.splice(0).forEach(c=>pc.addIceCandidate(c).catch(()=>{}))};return pc}
async function mic(video){if(!navigator.mediaDevices||!window.RTCPeerConnection){tt('यो फोनमा कल मिल्दैन','Calls are not supported on this device');return null}
  try{return await navigator.mediaDevices.getUserMedia(video?{audio:true,video:{facingMode:'user',width:{ideal:640},height:{ideal:480}}}:{audio:true})}catch(_){tt(video?'क्यामेरा र माइक्रोफोनको अनुमति दिनुहोस्':'माइक्रोफोनको अनुमति दिनुहोस्',video?'Please allow camera and microphone access':'Please allow microphone access');return null}}
window.mbCall=async function(c,video){if(c.g)return;const u=me();if(!u||cur)return;const to=c.m.find(x=>x!==u.uid);if(!to)return;const nm=(c.names||{})[to]||'?',st=await mic(video);if(!st)return;
  try{const doc=db().collection('calls').doc(),pc=mk(doc,true,nm,video);cur.stream=st;st.getTracks().forEach(t=>pc.addTrack(t,st));ctl(nm,ne()?'घण्टी बज्दैछ...':'Calling...');
    const off=await pc.createOffer();await pc.setLocalDescription(off);
    await doc.set({from:u.uid,to,cid:c.id,fn:S.u.shop?S.u.shop.name:S.u.name,st:'ring',v:video?1:0,ts:Date.now(),offer:{type:off.type,sdp:off.sdp}});cur.flushOut();cur.listen();
    cur.tm=setTimeout(()=>{if(cur&&!cur.t0){tt('कसैले उठाएन','No answer');hang()}},45000)}catch(e){close();tt('कल सुरु भएन: '+(e.code||e.message),'Call failed: '+(e.code||e.message))}};
async function answer(ref,d){const st=await mic(d.v);if(!st){ref.update({st:'rej'}).catch(()=>{});close();return}beep(false);
  try{const pc=mk(ref,false,d.fn,d.v);cur.stream=st;st.getTracks().forEach(t=>pc.addTrack(t,st));cur.flushOut();cur.listen();await pc.setRemoteDescription(d.offer);cur.rdy();
    const an=await pc.createAnswer();await pc.setLocalDescription(an);await ref.update({answer:{type:an.type,sdp:an.sdp},st:'acc'});ctl(d.fn,ne()?'जोड्दै...':'Connecting...');
    cur.tm=setTimeout(()=>{if(cur&&!cur.t0){hang()}},30000)}catch(e){close();tt('कल उठाउन सकिएन','Could not answer')}}
let lu=null;
setInterval(()=>{const u=me();if(u&&!lu){lu=db().collection('calls').where('to','==',u.uid).where('st','==','ring').onSnapshot(s=>s.docChanges().forEach(ch=>{const d=ch.doc.data();
    if(ch.type=='removed'){if(inc==ch.doc.id&&!cur)close();return}if(ch.type!='added'||Date.now()-d.ts>50000)return;if(cur||inc){ch.doc.ref.update({st:'rej'}).catch(()=>{});return}
    inc=ch.doc.id;beep(true);show(d.fn,d.v?(ne()?'भिडियो कल आयो':'Incoming video call'):(ne()?'तपाईंलाई कल आयो':'Incoming call'),[[d.v?'🎥':'📞','#2e7d32',()=>answer(ch.doc.ref,d)],['📵','#c62828',()=>{ch.doc.ref.update({st:'rej'}).catch(()=>{});close()}]])}),()=>{})}
  else if(!u&&lu){lu();lu=null}},2500);
})();
