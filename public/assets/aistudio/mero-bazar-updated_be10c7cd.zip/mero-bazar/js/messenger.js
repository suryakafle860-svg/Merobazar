/* Mero Bazar Messenger entry + online video/audio calls (1:1 only) + Direct calling (phone dialer). ADD-ON ONLY.
   Reuses chat.js (chats, groups, voice notes) and call.js (WebRTC audio/video via Firestore `calls`).
   Groups: messages only, no calls (call.js already refuses groups). Adds: reachable menu entries, a 🎥 button in 1:1 chats,
   shop-page Message / Direct-call buttons, and the Direct calling screen (tel: links). Uses no new Firestore collections. */
(function(){
'use strict';
const ne=()=>typeof DB!=='undefined'&&!!DB&&DB.lang==='ne',L=(a,b)=>ne()?a:b;
const me=()=>{try{return firebase.auth().currentUser}catch(_){return null}};
const tel=n=>{n=String(n||'').replace(/[^\d+]/g,'');if(/^9\d{9}$/.test(n))n='+977'+n;return n};
const BTN='padding:10px 14px;border:0;border-radius:10px;font-size:14px;font-weight:700;background:var(--ind,#1E2B6E);color:#fff;cursor:pointer;text-decoration:none;display:inline-block';
const lk=(s,i,t)=>'<div class="c row" style="cursor:pointer" onclick="S.sub=\''+s+'\';R()"><span>'+i+' <b>'+t+'</b></span><b>›</b></div>';

/* video button inside 1:1 chat header (re-uses the existing 📞 button's closure) */
const _mc=window.mbCall;if(typeof _mc=='function')window.mbCall=function(c,v){return _mc.call(this,c,v||window.__xv)};
new MutationObserver(()=>{try{const ct=document.getElementById('ct');if(!ct||document.getElementById('xvid'))return;
  const ph=[...ct.querySelectorAll('button')].find(b=>b.textContent.trim()==='📞');if(!ph)return;
  const v=document.createElement('button');v.id='xvid';v.textContent='🎥';v.title=L('भिडियो कल','Video call');v.style.cssText='padding:6px 10px;border:0;border-radius:8px;font-size:16px;margin-left:6px';
  v.onclick=()=>{window.__xv=1;try{ph.click()}finally{window.__xv=0}};ph.title=L('अडियो कल','Audio call');ct.appendChild(v)}catch(_){}}).observe(document.body,{childList:true,subtree:true});

const SVX={};
SVX.xmsg=()=>{const on=!!me(),C=DB.users.filter(u=>u._uid&&u.shop&&u._r&&u.id!==S.u.id);
  return '<h3>💬 Messenger</h3><div class="c st" style="text-transform:none;line-height:1.6">📞 '+L('व्यक्तिगत च्याटमा अडियो र भिडियो कल (इन्टरनेटबाट)','Audio & video calls in personal chats (over the internet)')+'<br>👥 '+L('सानो समूह बनाउन मिल्छ — समूहमा सन्देश मात्र, कल हुँदैन','Small groups are for messages only — no calls in groups')+'</div>'+
  (on?'':'<div class="c" style="border-left:4px solid #c62828">⚠️ '+L('क्लाउड जोडिएको छैन — लगआउट गरी फेरि लगइन गर्नुहोस्','Cloud not connected — log out and log in again')+'</div>')+
  '<button style="'+BTN+';width:100%;margin:8px 0" onclick="typeof obMsgs==\'function\'&&obMsgs()">💬 '+L('मेरा सन्देश / नयाँ समूह','My messages / New group')+'</button>'+
  '<h3>'+L('पसलसँग कुरा गर्नुहोस्','Chat with a shop')+'</h3>'+(C.map(s=>'<div class="c row"><b>🏪 '+E(s.shop.name)+'</b><button class="btn sm s" onclick="typeof obChat==\'function\'&&obChat(\''+E(s._uid)+'\',\''+E(s.shop.name).replace(/\'/g,'')+'\')">💬</button></div>').join('')||'<div class="c st">'+L('अहिले कुनै पसल उपलब्ध छैन','No shops available yet')+'</div>')};
SVX.xdial=()=>{const P=DB.users.filter(u=>u.shop&&u.phone&&u.id!==S.u.id&&(u.role!='m'||u.shop.ok||u.shop.demo));
  return '<h3>📱 '+L('डाइरेक्ट कलिङ','Direct calling')+'</h3><div class="c st" style="text-transform:none;line-height:1.6">'+L('यसले तपाईंको फोनको सिम/डाइलरबाट साधारण कल गर्छ (इन्टरनेट चाहिँदैन)। इन्टरनेटबाट कल गर्न Messenger प्रयोग गर्नुहोस्।','This places a normal phone call from your SIM/dialer (no internet needed). For internet calls use Messenger.')+'</div>'+
  '<div class="xp" style="background:var(--card);border:1px solid var(--ln);border-radius:12px;padding:10px;margin:8px 0"><input id="xdn" type="tel" inputmode="tel" maxlength="16" placeholder="98XXXXXXXX" style="width:100%;padding:12px;border:1px solid var(--ln);border-radius:10px;font-size:18px;background:var(--card);color:inherit;margin-bottom:8px"><a id="xdc" href="#" style="'+BTN+';background:#2e7d32;width:100%;text-align:center;box-sizing:border-box" onclick="return xDial()">📞 '+L('कल गर्नुहोस्','Call')+'</a></div>'+
  (S.u.phone?'<div class="st" style="text-transform:none;margin:4px 2px">'+L('तपाईंको नम्बर','Your number')+': <b>'+E(S.u.phone)+'</b></div>':'')+
  '<h3>'+L('पसलका नम्बर','Shop numbers')+'</h3>'+(P.map(s=>'<div class="c row"><span><b>'+E(s.shop.name)+'</b><div class="st" style="text-transform:none">'+E(s.phone)+'</div></span><a class="btn sm" style="'+BTN+';background:#2e7d32" href="tel:'+E(tel(s.phone))+'">📞</a></div>').join('')||'<div class="c st">'+L('नम्बर भएका पसल छैनन्','No shops with numbers yet')+'</div>')};
window.xDial=()=>{const n=tel(document.getElementById('xdn').value);if(!/^\+?\d{7,15}$/.test(n)){toast(L('मान्य नम्बर लेख्नुहोस्','Enter a valid number'));return false}document.getElementById('xdc').href='tel:'+n;return true};
if(typeof SV=='object')Object.assign(SV,SVX);

function decorate(){['xmx','xshopc'].forEach(i=>{const e=document.getElementById(i);if(e)e.remove()});
  if(typeof S==='undefined'||!S.u||typeof DB==='undefined'||!DB)return;const m=document.querySelector('.main');if(!m)return;const r=S.u.role;
  const links=()=>lk('xmsg','💬','Messenger')+lk('xdial','📱',L('डाइरेक्ट कलिङ','Direct calling'));
  if(!S.sub&&((r=='c'&&S.tab=='me')||(r=='m'&&S.tab=='more'&&S.u.shop)||(r=='a'&&S.tab=='more'))){const d=document.createElement('div');d.id='xmx';d.innerHTML=links();const pl=document.getElementById('plinks');pl?m.insertBefore(d,pl):m.insertBefore(d,m.firstChild)}
  if(S.sub=='shop'&&S.sid&&r=='c'){const s=U(S.sid);if(!s||!s.shop)return;const d=document.createElement('div');d.id='xshopc';d.style.cssText='display:flex;gap:8px;margin-bottom:10px';
    d.innerHTML='<button style="'+BTN+';flex:1" onclick="typeof obChat==\'function\'&&obChat(\''+E(s._uid||'')+'\',\''+E(s.shop.name).replace(/\'/g,'')+'\')">💬 '+L('सन्देश / कल','Message / Call')+'</button>'+(s.phone?'<a style="'+BTN+';background:#2e7d32;flex:1;text-align:center" href="tel:'+E(tel(s.phone))+'">📱 '+L('डाइरेक्ट कल','Direct call')+'</a>':'');
    const b=m.querySelector('button.btn');b?b.parentNode.insertBefore(d,b.nextSibling):m.insertBefore(d,m.firstChild)}}
const _R=window.R;if(typeof _R!=='function')return;
window.R=function(){const r=_R.apply(this,arguments);try{decorate()}catch(e){console.warn('msgr',e)}return r};
setTimeout(()=>{try{if(S.u)R()}catch(_){}},1000);
})();
