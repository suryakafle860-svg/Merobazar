/* Mero Bazar: after registration, auto-download one picture card with all registration details (password is never included) */
(function(){
const ne=()=>(window.DB&&DB.lang)!='en';
const img=s=>new Promise(ok=>{if(!s)return ok(null);const i=new Image();i.onload=()=>ok(i);i.onerror=()=>ok(null);i.src=s});
function wrap(c,t,w){const out=[];String(t==null?'':t).split('\n').forEach(p=>{let l='';p.split(' ').forEach(x=>{const y=l?l+' '+x:x;if(c.measureText(y).width>w&&l){out.push(l);l=x}else l=y});out.push(l)});return out}
window.regCard=async function(u,d){
  const n=ne(),W=900,P=36,c0=document.createElement('canvas'),m=c0.getContext('2d');
  const note=n?'यो तपाईँलाई पछि कुनै समस्या आएमा यही दर्ताको आधारमा तपाईंले रिपोर्ट गर्न सक्नुहुनेछ।':'If you face any problem later, you can report it based on this registration.';
  const role=u.role=='m'?(n?'व्यापारी':'Merchant'):(n?'ग्राहक':'Customer');
  const rows=[[n?'खाता कोड':'Account code',u.code],[n?'दर्ता मिति':'Registered on',new Date().toISOString().slice(0,10)],[n?'प्रकार':'Type',role],[n?'पूरा नाम':'Full name',u.name],[n?'इमेल':'Email',u.email],[n?'मोबाइल':'Mobile',u.phone],[n?'जन्म मिति':'Date of birth',u.dob],[n?'लिङ्ग':'Gender',u.gn],[n?'ठेगाना':'Address',[u.prov,u.dist,u.local,(n?'वडा ':'Ward ')+u.ward].filter(Boolean).join(', ')]];
  if(u.shop){const s=u.shop;rows.push([n?'पसलको नाम':'Shop name',s.name],[n?'पसलको प्रकार':'Shop type',s.type]);if(s.pan)rows.push(['PAN',s.pan]);if(s.lrn)rows.push([n?'स्थानीय दर्ता नं.':'Local registration no.',s.lrn]);if(d&&d.pm)rows.push([n?'भुक्तानी माध्यम':'Payment method',d.pm]);if(d&&d.ref)rows.push([n?'ट्रान्जेक्सन ID':'Transaction ID',d.ref])}
  rows.push([n?'पासवर्ड':'Password',n?'सुरक्षाका लागि यहाँ राखिएको छैन':'not included for your safety']);
  const ph=await img(u.photo),dc=u.shop?await img(u.shop.doc):null;
  m.font='22px sans-serif';const noteL=wrap(m,note,W-2*P-40);
  const lh=34;let h=150+noteL.length*30+40;
  rows.forEach(r=>{m.font='24px sans-serif';r.l=wrap(m,r[1],W-2*P-280);h+=Math.max(1,r.l.length)*lh+10});
  const fit=(i,mw,mh)=>{const k=Math.min(mw/i.width,mh/i.height,1);return[i.width*k,i.height*k]};
  if(ph)h+=330;if(dc)h+=430;h+=70;
  c0.width=W;c0.height=h;const g=c0.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,W,h);
  g.fillStyle='#0F4C9A';g.fillRect(0,0,W,110);g.fillStyle='#fff';g.font='bold 40px sans-serif';g.fillText('मेरो बजार · Mero Bazar',P,50);g.font='24px sans-serif';g.fillText(n?'दर्ता प्रमाण':'Registration record',P,88);
  let y=130;g.fillStyle='#FFF4E0';g.fillRect(P-8,y,W-2*P+16,noteL.length*30+28);g.fillStyle='#8A4B00';g.font='bold 24px sans-serif';noteL.forEach((t,i)=>g.fillText(t,P+8,y+34+i*30));y+=noteL.length*30+60;
  rows.forEach(r=>{g.fillStyle='#667';g.font='22px sans-serif';g.fillText(r[0],P,y+24);g.fillStyle='#111';g.font='bold 24px sans-serif';r.l.forEach((t,i)=>g.fillText(t,P+270,y+24+i*lh));y+=Math.max(1,r.l.length)*lh+10;g.strokeStyle='#e3e6ee';g.beginPath();g.moveTo(P,y-3);g.lineTo(W-P,y-3);g.stroke()});
  if(ph){g.fillStyle='#667';g.font='22px sans-serif';g.fillText(n?'प्रोफाइल फोटो':'Profile photo',P,y+30);const[a,b]=fit(ph,300,260);g.drawImage(ph,P,y+44,a,b);y+=330}
  if(dc){g.fillStyle='#667';g.font='22px sans-serif';g.fillText(n?'व्यवसाय दर्ता कागजात':'Business registration document',P,y+30);const[a,b]=fit(dc,W-2*P,360);g.drawImage(dc,P,y+44,a,b);y+=430}
  g.fillStyle='#999';g.font='20px sans-serif';g.fillText('Mero Bazar · '+location.hostname,P,h-26);
  const name='mero-bazar-darta-'+u.code+'.png';
  c0.toBlob(b=>{if(!b)return;const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(a.href)},4000)},'image/png');
};
})();
