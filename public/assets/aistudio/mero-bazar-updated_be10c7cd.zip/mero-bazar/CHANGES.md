# Added in this update (nothing existing was edited except 3 one-line wiring changes)

New file: `js/ext.js` (all new features live here; wraps existing functions, adds screens to `SV`).
Wiring edits: `index.html` (+1 script tag), `sw.js` (cache v ob-9 + ext.js), `firestore.rules` (+ `reviews` block).

**You must re-publish `firestore.rules`** (Firebase Console > Firestore > Rules) for ratings/reviews to save.

Customer: Trending / Discount offers / Popular shops / Recommended / Followed-shops strips on Home;
Filters (price, distance, ward, rating, in-stock); Ratings & reviews; Save shop/product; Follow shop;
Block shop; Address management (+ address picker in cart, shown to merchant on the order);
Order tracking timeline; Loyalty screen; Smart finder (cheapest first) + product comparison;
Share shop; Call history.
Merchant: Business insights (today/month sales, customer count, 7-day graph, best sellers, stock alert,
demand prediction, price suggestion, marketing tips, real rating); Featured product; Out-of-stock toggle;
Holiday settings (blocks add-to-cart); Quick replies in chat; Khata payment reminder + CSV export.
Admin: Fraud & risk check (duplicate txn IDs, shared PAN, odd prices, many cancels/complaints).

Messenger update: js/messenger.js (Messenger entry, 🎥 video button in 1:1 chats, groups = messages only, Direct calling screen via tel:).
